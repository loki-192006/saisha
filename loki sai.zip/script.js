/* ═══════════════════════════════════════════════════════
   SAI SHA INTERIOR — Ultra Premium Cinematic Interactions
   ═══════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ─── LOADER (CINEMATIC) ─── */
  const loader = document.getElementById('loader');

  window.addEventListener('load', function () {
    /* Slightly longer wait for a more deliberate, expensive feel */
    setTimeout(function () {
      if (loader) {
        loader.classList.add('hidden');
        /* Trigger hero animations manually once loader starts fading */
        setTimeout(() => {
          document.querySelectorAll('#home .reveal').forEach(el => el.classList.add('visible'));
        }, 400);
      }
    }, 2500);
  });


  /* ─── NAVBAR SCROLL ─── */
  const navbar = document.getElementById('navbar');
  
  function onScroll() {
    const y = window.scrollY || window.pageYOffset;
    if (y > 60) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', onScroll, { passive: true });


  /* ─── MOBILE MENU ─── */
  const toggle = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');

  if (toggle && navMenu) {
    toggle.addEventListener('click', function () {
      const isOpen = toggle.classList.toggle('open');
      navMenu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    navMenu.querySelectorAll('.navbar__link').forEach(link => {
      link.addEventListener('click', () => {
        toggle.classList.remove('open');
        navMenu.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });
  }


  /* ─── SMOOTH SCROLL ─── */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (!href || href === '#') return;
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        const offset = navbar ? navbar.offsetHeight : 80;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });


  /* ─── REVEAL ON SCROLL (CINEMATIC) ─── */
  const revealEls = document.querySelectorAll('.reveal');
  
  if ('IntersectionObserver' in window) {
    const observerOptions = {
      threshold: 0.15,
      rootMargin: '0px 0px -100px 0px'
    };

    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          
          /* If it's a stats section, trigger counter */
          if (entry.target.classList.contains('experience__stats')) {
            startCounters(entry.target);
          }
          
          revealObserver.unobserve(entry.target);
        }
      });
    }, observerOptions);

    revealEls.forEach(el => revealObserver.observe(el));
    
    /* Special observer for stats since they are inside a reveal el */
    const statsContainer = document.querySelector('.experience__stats');
    if (statsContainer) revealObserver.observe(statsContainer);

  } else {
    revealEls.forEach(el => el.classList.add('visible'));
  }


  /* ─── ANIMATED COUNTERS ─── */
  function startCounters(container) {
    const counters = container.querySelectorAll('[data-target]');
    counters.forEach(counter => {
      const target = parseFloat(counter.getAttribute('data-target'));
      const duration = 2000; // 2 seconds
      const stepTime = 20;
      const steps = duration / stepTime;
      const increment = target / steps;
      let current = 0;

      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          counter.innerText = target % 1 === 0 ? target : target.toFixed(1);
          clearInterval(timer);
        } else {
          counter.innerText = target % 1 === 0 ? Math.floor(current) : current.toFixed(1);
        }
      }, stepTime);
    });
  }


  /* ─── HERO PARTICLES (SUBTLE FLOATING) ─── */
  const particleContainer = document.getElementById('heroParticles');
  if (particleContainer) {
    for (let i = 0; i < 30; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      
      const size = Math.random() * 3 + 1;
      const posX = Math.random() * 100;
      const posY = Math.random() * 100;
      const delay = Math.random() * 10;
      const duration = 15 + Math.random() * 20;
      
      particle.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        background: var(--gold);
        opacity: ${Math.random() * 0.3};
        border-radius: 50%;
        top: ${posY}%;
        left: ${posX}%;
        animation: float ${duration}s ${delay}s infinite linear;
        pointer-events: none;
      `;
      particleContainer.appendChild(particle);
    }
  }

  /* Add keyframes dynamically for floating */
  const style = document.createElement('style');
  style.innerHTML = `
    @keyframes float {
      0% { transform: translateY(0) translateX(0); opacity: 0; }
      10% { opacity: 0.3; }
      90% { opacity: 0.3; }
      100% { transform: translateY(-100px) translateX(50px); opacity: 0; }
    }
  `;
  document.head.appendChild(style);


  /* ─── PARALLAX EFFECTS ─── */
  const heroImg = document.getElementById('heroParallaxImg');
  const heroText = document.querySelector('.hero__left');

  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    
    if (heroImg && y < 1000) {
      heroImg.style.transform = `translateY(${y * 0.15}px) scale(${1 + y * 0.0001})`;
    }
    
    if (heroText && y < 1000) {
      heroText.style.transform = `translateY(${y * 0.05}px)`;
      heroText.style.opacity = 1 - (y * 0.001);
    }
  }, { passive: true });


  /* ─── IMAGE HOVER DEPTH ─── */
  document.querySelectorAll('.proj-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const rotateX = (y - centerY) / 25;
      const rotateY = (centerX - x) / 25;
      
      const img = card.querySelector('img');
      if (img) {
        img.style.transform = `scale(1.1) translate(${(x - centerX)/20}px, ${(y - centerY)/20}px)`;
      }
    });
    
    card.addEventListener('mouseleave', () => {
      const img = card.querySelector('img');
      if (img) {
        img.style.transform = 'scale(1) translate(0, 0)';
      }
    });
  });

})();
